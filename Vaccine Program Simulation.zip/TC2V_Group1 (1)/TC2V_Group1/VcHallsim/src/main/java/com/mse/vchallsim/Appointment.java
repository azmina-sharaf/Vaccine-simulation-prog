/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mse.vchallsim;

/**
 *
 * @author Azmina
 * POJO for Recipient Appointment Details
 */
public class Appointment {
     private String vaccinationCenter;
     private String appointmentDT;
/**
 * 
 * @return Vaccination Center
 */
    public String getVaccinationCenter() {
        return vaccinationCenter;
    }
    /**
     * 
     * @param vaccinationCenter 
     */

    public void setVaccinationCenter(String vaccinationCenter) {
        this.vaccinationCenter = vaccinationCenter;
    }
    /**
     * 
     * @return Appointment Date
     */

    public String getAppointmentDT() {
        return appointmentDT;
    }
/**
 * 
 * @param appointmentDT 
 */
    public void setAppointmentDT(String appointmentDT) {
        this.appointmentDT = appointmentDT;
    }
     
     
     
}
