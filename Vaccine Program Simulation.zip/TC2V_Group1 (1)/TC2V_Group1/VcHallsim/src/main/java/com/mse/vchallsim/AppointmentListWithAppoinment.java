/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mse.vchallsim;

/**
 *
 * @author Azmina
 * POJO for json file
 */
public class AppointmentListWithAppoinment {

    /**
     *
     */
    private String phoneNumber;

    /**
     *
     */
    private String name;

    /**
     *
     */
    private int age;

    /**
     *
     */
    private int vaccinationStatus; 

    /**
     *
     */
    private Appointment appointment;  
/**
 * 
 * @return Recipient's phone number 
 */
    public String getPhoneNumber() {
        return phoneNumber;
    }
    
    /**
     * 
     * @param phoneNumber 
     */

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
    /**
     * 
     * @return Recipient's name
     */

    public String getName() {
        return name;
    }
    /**
     * 
     * @param name 
     */

    public void setName(String name) {
        this.name = name;
    }
/**
 * 
 * @return Recipient's age
 */
    public int getAge() {
        return age;
    }
   
    /**
     * 
     * @param age 
     */

    public void setAge(int age) {
        this.age = age;
    }
    /**
     * 
     * @return Recipient's vaccination status
     */

    public int getVaccinationStatus() {
        return vaccinationStatus;
    }
    /**
     * 
     * @param vaccinationStatus 
     */

    public void setVaccinationStatus(int vaccinationStatus) {
        this.vaccinationStatus = vaccinationStatus;
    }
/**
 * 
 * @return Appointment Date and  Center
 */
    public Appointment getAppointment() {
        return appointment;
    }
    /**
     * 
     * @param appointment 
     */

    public void setAppointment(Appointment appointment) {
        this.appointment = appointment;
    }
    
}
