/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mse.vchallsim;
import io.restassured.RestAssured;
/**
 * Parses .json to object
 * @author Azmina
 */
public class NestedJsonToPOJO {
      public static void main(String[] args){
       
          AppointmentListWithAppoinment list = RestAssured.get("https://run.mocky.io/v3/eabc8d00-3e33-4464-adc0-ea759db01ab5")
          .as(AppointmentListWithAppoinment.class);
            
          
          String n = list.getName();
          int a = list.getAge();
          Appointment appointment = list.getAppointment();
          
          System.out.println(n + a + appointment);  
          
      }
}
