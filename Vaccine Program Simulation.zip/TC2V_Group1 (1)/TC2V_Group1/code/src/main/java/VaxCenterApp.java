import java.io.IOException;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Collections;

import javafx.application.Application;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.Rectangle2D;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Tooltip;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Screen;
import javafx.stage.Stage;

public class VaxCenterApp extends Application {
    private Stage window;
    //private Button btShowRecipientScreen;
    private Button btnShowVCScreen;
    //private Button btShowMOHScreen;
    private Button[] navButtons;
    private StackPane ctnContent;
    private String phoneNumber = "";
    private String fullName = "";

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        window = primaryStage;
        window.setScene(new CustomScene(new StartScreen()));
        window.setTitle("Vaccination Center");
        //window.getIcons().add(new Image(VaxCenterApp.class.getResourceAsStream("C:\\Users\\Sandra\\baby's work\\school\\vc auto date\\code\\covid-vaccine-icon.png")));
        window.setMaxWidth(1000);
        window.setMaxHeight(600);
        window.setMinWidth(1000);
        window.setMinHeight(600);
        window.resizableProperty().setValue(false);
        //window.centerOnScreen();
        window.show();
        /* Rectangle2D screenBounds = Screen.getPrimary().getVisualBounds();
        window.setX((screenBounds.getWidth() - window.getWidth() / 2));
        window.setY((screenBounds.getHeight() - window.getHeight() / 2)); */

    }

    static class CustomScene extends Scene {
        public CustomScene(Parent parent) {
            super(parent);
            getStylesheets().add(getClass().getResource("style.css").toExternalForm());
        }

        public CustomScene(Parent parent, double v, double v1) {
            super(parent, v, v1);
            getStylesheets().add(getClass().getResource("style.css").toExternalForm());
        }
    }

    class StartScreen extends GridPane  {
        public StartScreen() {
            setVgap(5);
            setAlignment(Pos.CENTER);
            setPadding(new Insets(0, 0, 0, 0));

           Label lbWelcomeMsg = new Label("WELCOME TO THE VACCINATION CENTRE DATABASE");
           lbWelcomeMsg.getStyleClass().add("text-title");
           GridPane.setHalignment(lbWelcomeMsg, HPos.CENTER);
           GridPane.setConstraints(lbWelcomeMsg, 0, 0);

           

            Button btnShowVCScreen = new Button("Start");
            btnShowVCScreen.setOnAction(e -> {
                try{
                    getChildren().clear();
                    getChildren().add(new VCForm());
                }
                catch(IOException ex){
                    ex.printStackTrace();
                }
            });
            GridPane.setHalignment(btnShowVCScreen, HPos.CENTER);
            GridPane.setConstraints(btnShowVCScreen, 0, 6);

            getChildren().addAll(lbWelcomeMsg, btnShowVCScreen);
        }

       

    
    }

    class VCForm extends GridPane {
        ArrayList<String> vcs;
        ComboBox<String> comboBoxVC;

        VCForm() throws IOException{
            vcs = new ArrayList<>();
            ArrayList<VaccinationCenter> temp = new JsonHelper().readJsonFileToArrayList(JsonHelper.VC_JSON_FILE, VaccinationCenter.class);
            for (VaccinationCenter vaccinationCenter : temp) {
                vcs.add(vaccinationCenter.getName());
            }

            setVgap(10);
            setAlignment(Pos.CENTER);
            setPadding(new Insets(0, 0, 0, 20));

            Label lbTitle = new Label("SELECT A CENTER");
            lbTitle.getStyleClass().add("text-title");
            GridPane.setHalignment(lbTitle, HPos.CENTER);
            GridPane.setConstraints(lbTitle, 0, 0);

            comboBoxVC = new ComboBox<>();
            comboBoxVC.getItems().addAll(vcs);
            comboBoxVC.setValue(vcs.get(0));
            GridPane.setHalignment(comboBoxVC, HPos.CENTER);
            GridPane.setConstraints(comboBoxVC, 0, 1);

            Button btnEnter = new Button("Enter");
            btnEnter.setOnAction(e -> {
                try {
                    VaccinationCenter vc = new VaccinationCenter(comboBoxVC.getValue());
                    window.setScene(new CustomScene(new VaccinationCenterLayout(vc), 1000, 600));
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            });
            GridPane.setConstraints(btnEnter, 0, 3);

            getChildren().addAll(lbTitle, comboBoxVC, btnEnter);
        }
    }

    static class AlertBox {
        public static void display(String title, String message) {
            Stage stage = new Stage();
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setTitle(title);
            stage.setMinWidth(250);

            StackPane layout = new StackPane();
            layout.setPadding(new Insets(50));
            layout.getChildren().add(new Label(message));
            layout.setAlignment(Pos.CENTER);

            stage.setScene(new CustomScene(layout));
            stage.showAndWait();
        }

        public static void displayFromLayout(String title, Pane layout) {
            Stage stage = new Stage();
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setTitle(title);
            stage.setScene(new CustomScene(layout, 400, 660));
            stage.setResizable(false);
            stage.showAndWait();
        }
    }

    //class MainMenuLayout extends GridPane implements EventHandler<ActionEvent> {
       // public MainMenuLayout() {
           // ColumnConstraints columnConstraints = new ColumnConstraints();
           // columnConstraints.setPercentWidth(25);
           // getColumnConstraints().add(columnConstraints);

          //  ColumnConstraints columnConstraints2 = new ColumnConstraints();
         //   columnConstraints2.setPercentWidth(75);
         //   getColumnConstraints().add(columnConstraints2);

         //   VBox ctnNav = new VBox();
         //   GridPane.setConstraints(ctnNav, 0, 0);
          //  ctnNav.setId("nav-pane");
          //  ctnNav.prefHeightProperty().bind(heightProperty());

           // StackPane ctnTitle = new StackPane();
           // ctnTitle.setAlignment(Pos.CENTER);
           // ctnTitle.setId("role-pane");
           // Label lbTitle = new Label("Covid 19 Program");
           // lbTitle.setPadding(new Insets(0, 0, 50, 0));
           // lbTitle.getStyleClass().add("menu-head-label");
           // ctnTitle.getChildren().add(lbTitle);

           // btShowRecipientScreen = new Button("Recipient");
           // btShowRecipientScreen.getStyleClass().addAll("nav-button", "nav-button-active");
           // btShowRecipientScreen.prefWidthProperty().bind(ctnNav.widthProperty());
           // btShowRecipientScreen.setOnAction(this);

           // btShowVCScreen = new Button("Vaccination Center");
           // btShowVCScreen.getStyleClass().add("nav-button");
           // btShowVCScreen.prefWidthProperty().bind(ctnNav.widthProperty());
           // btShowVCScreen.setOnAction(this);

          //  btShowMOHScreen = new Button("Ministry of Health");
          //  btShowMOHScreen.getStyleClass().add("nav-button");
          //  btShowMOHScreen.prefWidthProperty().bind(ctnNav.widthProperty());
          //  btShowMOHScreen.setOnAction(this);

          //  navButtons = new Button[]{ btShowVCScreen};

          //  ctnNav.getChildren().addAll(ctnTitle, btShowVCScreen);

           // ctnContent = new StackPane();
           // ctnContent.setAlignment(Pos.CENTER);
           // GridPane.setConstraints(ctnContent, 1, 0);

            //ctnContent.getChildren().add(new SignUpForm());

           // getChildren().addAll(ctnNav, ctnContent);
      //  }

      //  @Override
       // public void handle(ActionEvent event) {
        //    ctnContent.getChildren().clear();
        //   if (event.getSource() == btShowVCScreen) {
        //        changeTab(0);
        //        try {
        //            ctnContent.getChildren().add(new VCForm());
          //      } catch (IOException e) {
         //           e.printStackTrace();
           //     }
           // } 
      //  }

      //  private void changeTab(int tabIndex) {
       //     for (Button navButton : navButtons) {
       //         navButton.getStyleClass().remove("nav-button-active");
       //     }
        //    navButtons[tabIndex].getStyleClass().add("nav-button-active");
      //  }
  //  }

    class RecipientLayout extends GridPane {
        private Button btShowDetails;
        private Button btLogout;
        private StackPane ctnContent;
        private Recipient recipient;

        RecipientLayout(Recipient recipient) {
            this.recipient = recipient;

            ColumnConstraints columnConstraints = new ColumnConstraints();
            columnConstraints.setPercentWidth(25);
            getColumnConstraints().add(columnConstraints);

            columnConstraints = new ColumnConstraints();
            columnConstraints.setPercentWidth(75);
            getColumnConstraints().add(columnConstraints);

            VBox ctnNav = new VBox();
            GridPane.setConstraints(ctnNav, 0, 0);
            ctnNav.setId("nav-pane");
            ctnNav.prefHeightProperty().bind(heightProperty());

            StackPane ctnTitle = new StackPane();
            ctnTitle.setAlignment(Pos.CENTER);
            ctnTitle.setId("role-pane");
            Label lbTitle = new Label("Welcome " + recipient.getName());
            lbTitle.setPadding(new Insets(0, 0, 50, 0));
            lbTitle.getStyleClass().add("menu-head-label");
            ctnTitle.getChildren().add(lbTitle);

            btShowDetails = new Button("Recipient");
            btShowDetails.getStyleClass().addAll("nav-button", "nav-button-active");
            btShowDetails.prefWidthProperty().bind(ctnNav.widthProperty());

            btLogout = new Button("Exit");
            btLogout.getStyleClass().add("nav-button");
            btLogout.prefWidthProperty().bind(ctnNav.widthProperty());
            btLogout.setOnAction(e -> window.setScene(new CustomScene(new StartScreen(), 1000, 600)));

            ctnNav.getChildren().addAll(ctnTitle, btShowDetails, btLogout);

            ctnContent = new StackPane();
            ctnContent.setAlignment(Pos.CENTER);
            ctnContent.getChildren().add(new RecipientDetailLayout(recipient));
            GridPane.setConstraints(ctnContent, 1, 0);

            getChildren().addAll(ctnNav, ctnContent);
        }
    }

    class RecipientDetailLayout extends GridPane {
        private Recipient recipient;
        private String[] vaccinationStatusDescription = {"", "Pending", "1st Dose Appointment", " Completed 1st Dose", "2nd Dose Appointment", " Completed 2nd Dose"};

        RecipientDetailLayout(Recipient recipient) {
            this.recipient = recipient;
            setVgap(10);
            setAlignment(Pos.CENTER);
            setPadding(new Insets(0, 0, 0, 20));

            Label lbFullName = new Label("Name");
            lbFullName.getStyleClass().add("text-title");
            GridPane.setConstraints(lbFullName, 0, 0);
            Label lbFullName2 = new Label(recipient.getName());
            GridPane.setConstraints(lbFullName2, 0, 1);
            Label lbEmpty = new Label("");
            GridPane.setConstraints(lbEmpty, 0, 2);

            Label lbAge = new Label("Age");
            lbAge.getStyleClass().add("text-title");
            GridPane.setConstraints(lbAge, 0, 3);
            Label lbAge2 = new Label(String.valueOf(recipient.getAge()));
            GridPane.setConstraints(lbAge2, 0, 4);
            Label lbEmpty5 = new Label("");
            GridPane.setConstraints(lbEmpty5, 0, 5);

            Label lbPhoneNo = new Label("Phone Number");
            lbPhoneNo.getStyleClass().add("text-title");
            GridPane.setConstraints(lbPhoneNo, 0, 6);
            Label lbPhoneNo2 = new Label(recipient.getPhoneNumber());
            GridPane.setConstraints(lbPhoneNo2, 0, 7);
            Label lbEmpty2 = new Label("");
            GridPane.setConstraints(lbEmpty2, 0, 8);

            Label lbStatus = new Label("Status");
            lbStatus.getStyleClass().add("text-title");
            GridPane.setConstraints(lbStatus, 0, 9);
            Label lbStatus2 = new Label(vaccinationStatusDescription[recipient.getVaccinationStatus()]);
            GridPane.setConstraints(lbStatus2, 0, 10);
            Label lbEmpty3 = new Label("");
            GridPane.setConstraints(lbEmpty3, 0, 11);

            Label lbAppointment = new Label("Appointments");
            lbAppointment.getStyleClass().add("text-title");
            GridPane.setConstraints(lbAppointment, 0, 12);
            Label lbDose1 = new Label();
            String messageDose1 = "Dose 1 is not appointed";
            if (recipient.getAppointments() != null && recipient.getAppointments().size() > 0) {
                if (recipient.getAppointments().get(0).getVaccinationCenter() != null
                        && recipient.getAppointments().get(0).getAppointmentDT() != null) {
                    messageDose1 = "Dose 1: " + recipient.getAppointments().get(0).getVaccinationCenter() + ", " + recipient.getAppointments().get(0).getAppointmentDT().toString().replace('T', ' ');
                }
            }
            lbDose1.setText(messageDose1);

            GridPane.setConstraints(lbDose1, 0, 13);
            Label lbDose2 = new Label();
            String messageDose2 = "Dose 2 is not appointed";
            if (recipient.getAppointments() != null && recipient.getAppointments().size() > 1) {
                if (recipient.getAppointments().get(1).getVaccinationCenter() != null
                        && recipient.getAppointments().get(1).getAppointmentDT() != null) {
                    messageDose2 = "Dose 2: " + recipient.getAppointments().get(1).getVaccinationCenter() + ", " + recipient.getAppointments().get(1).getAppointmentDT().toString().replace('T', ' ');
                }
            }
            lbDose2.setText(messageDose2);
            GridPane.setConstraints(lbDose2, 0, 14);

            Label lbEmpty4 = new Label("");
            GridPane.setConstraints(lbEmpty4, 0, 15);

            getChildren().addAll(lbFullName, lbFullName2, lbEmpty, lbPhoneNo, lbPhoneNo2, lbEmpty2, lbStatus, lbStatus2, lbEmpty3, lbAppointment, lbDose1, lbDose2, lbEmpty4, lbAge, lbAge2, lbEmpty5);
        }
    }

    class VaccinationCenterLayout extends GridPane implements EventHandler<ActionEvent> {
        private VaccinationCenter vaccinationCenter;
        private Button btDashboard, btRecipients, btLogOut;
        private Button[] navButtons;
        private StackPane ctnSubContent;

        VaccinationCenterLayout(VaccinationCenter vaccinationCenter) {
            this.vaccinationCenter = vaccinationCenter;

            ColumnConstraints columnConstraints = new ColumnConstraints();
            columnConstraints.setPercentWidth(20);
            getColumnConstraints().add(columnConstraints);

            ColumnConstraints columnConstraints2 = new ColumnConstraints();
            columnConstraints2.setPercentWidth(80);
            getColumnConstraints().add(columnConstraints2);

            VBox ctnSubNav = new VBox();
            ctnSubNav.prefWidthProperty().bind(widthProperty());
            ctnSubNav.prefHeightProperty().bind(heightProperty());
            ctnSubNav.setId("nav-pane");
            GridPane.setConstraints(ctnSubNav, 0, 0);

            StackPane ctnRole = new StackPane();
            ctnRole.setAlignment(Pos.CENTER);
            ctnRole.setId("role-pane");
            Label lbRole = new Label(vaccinationCenter.getName());
            lbRole.setPadding(new Insets(0, 0, 50, 0));
            lbRole.getStyleClass().add("menu-head-label");
            ctnRole.getChildren().add(lbRole);

            btDashboard = new Button("Dashboard");
            btDashboard.getStyleClass().addAll("nav-button", "nav-button-active");
            btDashboard.prefWidthProperty().bind(ctnSubNav.widthProperty());
            btDashboard.setOnAction(this);

            btRecipients = new Button("Recipients");
            btRecipients.getStyleClass().add("nav-button");
            btRecipients.prefWidthProperty().bind(ctnSubNav.widthProperty());
            btRecipients.setOnAction(this);

            btLogOut = new Button("Exit");
            btLogOut.getStyleClass().add("nav-button");
            btLogOut.prefWidthProperty().bind(ctnSubNav.widthProperty());
            btLogOut.setOnAction(this);

            navButtons = new Button[]{btDashboard, btRecipients, btLogOut};

            ctnSubNav.getChildren().addAll(ctnRole, btDashboard, btRecipients, btLogOut);

            ctnSubContent = new StackPane();
            ctnSubContent.setAlignment(Pos.CENTER);
            setColumnIndex(ctnSubContent, 1);

            ctnSubContent.getChildren().add(new DashboardLayout(vaccinationCenter.getRecipients(), vaccinationCenter));
            getChildren().addAll(ctnSubNav, ctnSubContent);
        }

        @Override
        public void handle(ActionEvent event) {
            ctnSubContent.getChildren().clear();
            if (event.getSource() == btDashboard) {
                changeTab(0);
                ctnSubContent.getChildren().add(new DashboardLayout(vaccinationCenter.getRecipients(), vaccinationCenter));
            } else if (event.getSource() == btRecipients) {
                changeTab(1);
                ctnSubContent.getChildren().add(new RecipientTableLayout(vaccinationCenter.getRecipients()));
            } else if (event.getSource() == btLogOut) {
                changeTab(2);
                window.setScene(new CustomScene(new StartScreen(), 1000, 600));
            }
        }

        private void changeTab(int tabIndex) {
            for (Button navButton : navButtons) {
                navButton.getStyleClass().remove("nav-button-active");
            }
            navButtons[tabIndex].getStyleClass().add("nav-button-active");
        }

        class DashboardLayout extends GridPane {
            ArrayList<Recipient> recipients;
            VaccinationCenter vaccinationCenter;


            public DashboardLayout(ArrayList<Recipient> recipients, VaccinationCenter vaccinationCenter) {
                this.recipients = recipients;
                this.vaccinationCenter = vaccinationCenter;

                setPadding(new Insets(20));
                setVgap(20);
                setHgap(10);

                String percentage = String.format("%.2f%%\nreceived only one dose", getPercentageOverTotalRecipients(getTotalRecipientWithOneDose()));
                Button bt1 = new Button(percentage);
                bt1.setStyle("-fx-background-color: #7f0000");
                bt1.getStyleClass().add("dashboard-button");

                percentage = String.format("%d\ndoses given today", getTotalDoseGivenToday());
                Button bt2 = new Button(percentage);
                bt2.setStyle("-fx-background-color: #003c8f");
                bt2.getStyleClass().add("dashboard-button");

                percentage = String.format("%.2f%%\nfully vaccinated", getPercentageOverTotalRecipients(getTotalFullyVaccinedRecipient()));
                Button bt3 = new Button(percentage);
                bt3.setStyle("-fx-background-color: #004c40");
                bt3.getStyleClass().add("dashboard-button");

                percentage = String.format("%d\ntotal vaccinations", getTotalDosesGiven());
                Button bt4 = new Button(percentage);
                bt4.setStyle("-fx-background-color: #003c8f");
                bt4.getStyleClass().add("dashboard-button");

                Button bt5 = new Button(vaccinationCenter.getAvailableVaccine()-getTotalDosesGiven() + "\nvaccines available");
                bt5.setStyle("-fx-background-color: #ffcc66");
                bt5.getStyleClass().add("dashboard-button");
                GridPane.setHalignment(bt5, HPos.CENTER);
                
                VBox vBox2 = new VBox();
                vBox2.setPadding(new Insets(10, 10, 10, 10));
                vBox2.setSpacing(10);
                vBox2.getChildren().addAll(bt1, bt3);
                vBox2.setAlignment(Pos.BOTTOM_CENTER);
                add(vBox2, 0, 0, 1, 2); 

                VBox vBox3 = new VBox();
                vBox3.setPadding(new Insets(10, 10, 10, 10));
                vBox3.setSpacing(10);
                vBox3.getChildren().addAll(bt2, bt4);
                add(vBox3, 1, 0, 1, 2); 

                add(bt5, 0, 2, 2, 1);
                
                //getChildren().addAll(bt1, bt2, bt3, bt4, bt5);
                //getChildren().addAll(vBox2, vBox3, bt5);
            }

            private long getTotalDoseGivenToday() {
                long count = 0;
                LocalDateTime today = LocalDateTime.now().truncatedTo(ChronoUnit.DAYS);
                for (Recipient recipient : recipients) {
                    if ((recipient.getVaccinationStatus() == 5 && recipient.getAppointments().get(1).getAppointmentDT()
                            .truncatedTo(ChronoUnit.DAYS).isEqual(today))
                            || (recipient.getVaccinationStatus() == 3 && recipient.getAppointments().get(0).getAppointmentDT()
                            .truncatedTo(ChronoUnit.DAYS).isEqual(today))
                            || (recipient.getVaccinationStatus() == 5 && recipient.getAppointments().get(0).getAppointmentDT()
                            .truncatedTo(ChronoUnit.DAYS).isEqual(today)))
                        count++;
                }
                return count;
            }

            private long getTotalDosesGiven() {
                long count = 0;
                LocalDateTime today = LocalDateTime.now().truncatedTo(ChronoUnit.DAYS);
                for (Recipient recipient : recipients) {
                    if ((recipient.getVaccinationStatus() == 3 ))
                        count++;
                    else if((recipient.getVaccinationStatus() == 5))
                        count += 2;
                }
                return count;
            }

            private long getTotalUnvaccinedRecipient() {
                long count = 0;
                for (Recipient recipient : recipients) {
                    if (recipient.getVaccinationStatus() == 1 || recipient.getVaccinationStatus() == 2)
                        count += 1;
                }
                return count;
            }

            private long getTotalRecipientWithOneDose() { // get number of people with 1 dose only
                long count = 0;
                for (Recipient recipient : recipients) {
                    if (recipient.getVaccinationStatus() == 3)
                        count += 1;
                }
                return count;
            }

            private long getTotalFullyVaccinedRecipient() {
                long count = 0;
                for (Recipient recipient : recipients) {
                    if (recipient.getVaccinationStatus() == 5)
                        count += 1;
                }
                return count;
            }

            private double getPercentageOverTotalRecipients(long totalFilteredRecipients) {
                long totalRecipients = recipients.size();
                return (1.0 * totalFilteredRecipients / totalRecipients) * 100;
            }

        }

        class RecipientTableLayout extends VBox {
            private ArrayList<Recipient> recipients;
            private TableView<Recipient> tblViewRecipient;
            private ArrayList<Recipient> temp;


            public RecipientTableLayout(ArrayList<Recipient> recipients) {
                temp = recipients;
                Collections.sort(temp);
                this.recipients = temp;
                setAlignment(Pos.CENTER);
                setPadding(new Insets(20));

                Label label = new Label();
                label.setPadding(new Insets(20));

                TextField tfName = new TextField();
                tfName.setPromptText("Enter name or phone no");
                Button btShowDetail = new Button("Show");
                Button btSetAppointment = new Button("Set Appointment");

                HBox hBox = new HBox();
                hBox.setPadding(new Insets(10, 10, 10, 10));
                hBox.setSpacing(10);
                hBox.getChildren().addAll(tfName, btShowDetail, btSetAppointment);


                TableColumn<Recipient, String> tblColName = new TableColumn<>("Name");
                tblColName.setMinWidth(100);
                tblColName.setCellValueFactory(new PropertyValueFactory<>("name"));

                TableColumn<Recipient, Integer> tblColAge = new TableColumn<>("Age");
                tblColAge.setMinWidth(25);
                tblColAge.setCellValueFactory(new PropertyValueFactory<>("age"));

                TableColumn<Recipient, String> tblColPhoneNo = new TableColumn<>("Phone No");
                tblColPhoneNo.setMinWidth(100);
                tblColPhoneNo.setCellValueFactory(new PropertyValueFactory<>("phoneNumber"));

                TableColumn<Recipient, Integer> tblColVCStatus = new TableColumn<>();
                Label status = new Label("Status");
                tblColVCStatus.setGraphic(status);
                Tooltip tooltip1 = new Tooltip("2: 1st Dose Appointment\n3: Completed 1st Dose\n4: 2nd Dose Appointment\n5: Completed 2nd Dose");
                status.setTooltip(tooltip1);
                tblColVCStatus.setMinWidth(55);
                tblColVCStatus.setCellValueFactory(new PropertyValueFactory<>("vaccinationStatus"));


                TableColumn<Recipient, String> tblColDose1VC = new TableColumn<>("Location");
                tblColDose1VC.setCellValueFactory(cellData -> {
                    String vc = "-";
                    if (cellData.getValue().getAppointments() != null && cellData.getValue().getAppointments().size() > 0) {
                        vc = cellData.getValue().getAppointments().get(0).getVaccinationCenter();
                    }
                    return new SimpleStringProperty(vc);
                });

                TableColumn<Recipient, String> tblColDose1DT = new TableColumn<>("Time");
                tblColDose1DT.setCellValueFactory(cellData -> {
                    String dt = "-";
                    if (cellData.getValue().getAppointments() != null && cellData.getValue().getAppointments().size() > 0) {
                        if (cellData.getValue().getAppointments().get(0).getAppointmentDT() != null) {

                            dt = cellData.getValue().getAppointments().get(0).getAppointmentDT().toString().replace('T', ' ');
                        }
                    }
                    return new SimpleStringProperty(dt);
                });

                TableColumn<Recipient, Appointment> tblColDose1 = new TableColumn<>("Dose 1");
                tblColDose1.getColumns().addAll(tblColDose1VC, tblColDose1DT);

                TableColumn<Recipient, String> tblColDose2VC = new TableColumn<>("Location");
                tblColDose2VC.setCellValueFactory(cellData -> {
                    String vc = "-";
                    if (cellData.getValue().getAppointments() != null && cellData.getValue().getAppointments().size() > 1) {
                        vc = cellData.getValue().getAppointments().get(1).getVaccinationCenter();
                    }
                    return new SimpleStringProperty(vc);
                });

                TableColumn<Recipient, String> tblColDose2DT = new TableColumn<>("Time");
                tblColDose2DT.setCellValueFactory(cellData -> {
                    String dt = "-";
                    if (cellData.getValue().getAppointments() != null && cellData.getValue().getAppointments().size() > 1) {
                        if (cellData.getValue().getAppointments().get(1).getAppointmentDT() != null) {
                            dt = cellData.getValue().getAppointments().get(1).getAppointmentDT().toString().replace('T', ' ');
                        }
                    }
                    return new SimpleStringProperty(dt);
                });

                TableColumn<Recipient, Appointment> tblColDose2 = new TableColumn<>("Dose 2");
                tblColDose2.getColumns().addAll(tblColDose2VC, tblColDose2DT);

                TableColumn<Recipient, Boolean> tblColAction = new TableColumn<>("Update Status");
                tblColAction.setMinWidth(100);
                tblColAction.setSortable(false);

                tblColAction.setCellFactory(
                        p -> {
                            try {
                                return new ButtonCell();
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                            return null;
                        });

                tblViewRecipient = new TableView<>();
                tblViewRecipient.setItems(FXCollections.observableArrayList(recipients));
                tblViewRecipient.getColumns().addAll(tblColName, tblColAge, tblColPhoneNo, tblColVCStatus, tblColDose1, tblColDose2, tblColAction);
                tblViewRecipient.getColumns().get(0).setVisible(false);
                tblViewRecipient.getColumns().get(0).setVisible(true);


                tblViewRecipient.setRowFactory(tv -> {
                    TableRow<Recipient> row = new TableRow<>();
                    row.setOnMouseClicked(e -> {
                        if (e.getClickCount() == 2 && (!row.isEmpty())) {
                            Recipient rowData = row.getItem();
                            AlertBox.displayFromLayout("Recipient Details", new RecipientDetailLayout(rowData));
                        }
                    });

                    return row;
                });

                tfName.textProperty().addListener((v, oldValue, newValue) -> {
                    ObservableList<Recipient> allRecipient = tblViewRecipient.getItems();
                    allRecipient.stream().filter(item -> item.getName().startsWith(newValue) || item.getPhoneNumber().startsWith(newValue)).findAny().ifPresent(item -> {
                        tblViewRecipient.getSelectionModel().select(item);
                        tblViewRecipient.scrollTo(item);
                    });
                });

                btShowDetail.setOnAction(e -> {
                    if (tblViewRecipient.getSelectionModel().getSelectedItem() != null) {
                        Recipient r = tblViewRecipient.getSelectionModel().getSelectedItem();
                        AlertBox.displayFromLayout("Recipient Details", new RecipientDetailLayout(r));
                    }
                });
                btSetAppointment.setOnAction(e -> {
                    try {
                        vaccinationCenter.setAppointmentDate();
                        tblViewRecipient.refresh();
                    } catch (IOException ex) {
                        ex.printStackTrace();
                    }
                });
                HBox.setHgrow(tfName, Priority.ALWAYS);

                
                getChildren().addAll(hBox, tblViewRecipient);
            }

            class ButtonCell extends TableCell<Recipient, Boolean> {
                Button btnCell;

                ButtonCell() throws IOException {
                    btnCell = new Button("+");
                    btnCell.setMaxWidth(50);
                    btnCell.setOnAction(e -> btnCellHandler());
                }

                private void btnCellHandler() {
                    try{
                        if (tblViewRecipient.getItems().get(super.getIndex()).getVaccinationStatus() < 5) {
                            vaccinationCenter.increaseVaccinationStatus(tblViewRecipient.getItems().get(super.getIndex()));
                            tblViewRecipient.refresh();
                        }
                    } catch (IOException ex) {ex.printStackTrace();}
                }

                @Override
                protected void updateItem(Boolean t, boolean empty) {
                    super.updateItem(t, empty);
                    if (!empty) {
                        setGraphic(btnCell);
                    }
                }
            }
        }
    }
}
