import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringReader;
import java.io.Writer;
import java.lang.reflect.Type;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Locale;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;

public class JsonHelper {
    public static final String RECIPIENT_JSON_FILE = "code/recipients3.json";
    public static final String VC_JSON_FILE = "code/vaccinationCenters.json";
    public static final String BATCH_JSON_FILE = "code/vaccineBatch.json";




    private final Gson gson;

    public JsonHelper() {
        GsonBuilder gsonBuilder = new GsonBuilder();
        gsonBuilder.registerTypeAdapter(LocalDateTime.class, new LocalDateTimeDeserializer());
        gsonBuilder.registerTypeAdapter(LocalDateTime.class, new LocalDateTimeSerializer());
        this.gson = gsonBuilder.setLenient().create();
    }

    static class LocalDateTimeDeserializer implements JsonDeserializer<LocalDateTime> {
        @Override
        public LocalDateTime deserialize(JsonElement jsonElement, Type type, JsonDeserializationContext jsonDeserializationContext) throws JsonParseException {
            return LocalDateTime.parse(jsonElement.getAsString(), DateTimeFormatter.ISO_LOCAL_DATE_TIME.withLocale(Locale.ENGLISH));
        }
    }

    static class LocalDateTimeSerializer implements JsonSerializer<LocalDateTime> {
        private static final DateTimeFormatter formatter = DateTimeFormatter.ISO_LOCAL_DATE_TIME;

        @Override
        public JsonElement serialize(LocalDateTime localDateTime, Type type, JsonSerializationContext jsonSerializationContext) {
            return new JsonPrimitive(formatter.format(localDateTime));
        }
    }


    public <T> ArrayList<T> readJsonFileToArrayList(String path, Class<T> className) throws IOException {
        Reader reader = Files.newBufferedReader(Paths.get(path));
        return gson.fromJson(reader, TypeToken.getParameterized(ArrayList.class, className).getType());
    }

    public <T> ArrayList<T> readJsonLinkToArrayList(String link, Class<T> className) throws IOException {
        BufferedReader reader = null;
        try{
            URL url = new URL(link);
            reader = new BufferedReader(new InputStreamReader(url.openStream()));
            StringBuffer buffer = new StringBuffer();
            int read;
            char[] chars = new char[1024];
            while ((read = reader.read(chars)) != -1)
                buffer.append(chars, 0, read); 

            buffer.toString();
        } finally {
            if (reader != null)
                reader.close();
        }
        return gson.fromJson(reader, TypeToken.getParameterized(ArrayList.class, className).getType());

    }

    public <T> void writeJsonFile(ArrayList<T> recipients, String path) throws IOException {
        Writer writer = Files.newBufferedWriter(Paths.get(path));
        gson.toJson(recipients, writer);
        writer.close();
    }

    public void appendJsonArray(Object newArrayObject, String path) throws IOException {
        ArrayList<Object> data = readJsonFileToArrayList(path, Object.class);
        data.add(newArrayObject);
        writeJsonFile(data, path);
    }

    public int vaxCounter(String path) throws IOException{

        Reader reader = Files.newBufferedReader(Paths.get(path));
        JsonArray obj = (JsonArray) JsonParser.parseReader(reader);
        int count = 0;
            for (Object o : obj){
              count++;
            }
        return count;
    }
    public int vaxCounterLink (String link) throws IOException{
        int count = 0;
        
        JsonReader reader = new JsonReader(new StringReader(link));
        reader.setLenient(true);
        JsonElement t = (JsonElement) JsonParser.parseReader(reader);
        JsonArray obj = (JsonArray) t;
            for (Object o : obj){
              count++;
            }
        return count;
    }

    /* public int vaxCounterLink (String link) throws IOException{
            URL url = new URL(link);
            HttpURLConnection httpcon = (HttpURLConnection) url.openConnection();
            InputStreamReader reader = new InputStreamReader(httpcon.getInputStream());
            JsonArray obj = (JsonArray) JsonParser.parseReader(reader);
            int count = 0;
            for (Object o : obj) {
                count++;
            }
            return count;
    } */

    private static String readUrl(String urlString) throws Exception {
        BufferedReader reader = null;
        try {
            URL url = new URL(urlString);
            reader = new BufferedReader(new InputStreamReader(url.openStream()));
            StringBuffer buffer = new StringBuffer();
            int read;
            char[] chars = new char[1024];
            while ((read = reader.read(chars)) != -1)
                buffer.append(chars, 0, read); 
    
            return buffer.toString();
        } finally {
            if (reader != null)
                reader.close();
        }
    }
}
