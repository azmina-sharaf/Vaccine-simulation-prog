import java.io.IOException;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Objects;

/**
 * This class is used to perform actions related to the appointments of vaccination such as displaying recipients who received their vaccines in the respective vaccination center and setting new appointments for them.
 */
public class VaccinationCenter {
    private static JsonHelper jsonHelper;
    private final static int NEXT_DOSE_DAYS = 21;
    private final String name;
    private ArrayList<Recipient> recipients;
    private int capacityPerHour;
    private int capacityPerDay;
    private int availableVaccine;

    /**
     * create a vaccination center identified by its name
     *
     * @param name name of the vaccination center
     */

    public VaccinationCenter(String name) throws IOException {
        jsonHelper = new JsonHelper();
        this.name = name;
        getRemainingInfo();
        loadData();
    }

    private void getRemainingInfo() throws IOException {
        ArrayList<VaccinationCenter> vcs = jsonHelper.readJsonFileToArrayList(JsonHelper.VC_JSON_FILE, VaccinationCenter.class);
        VaccinationCenter vc = vcs.stream().filter(r -> r.equals(this)).findAny().orElse(null);
        this.capacityPerDay = vc.getCapacityPerDay();
        this.availableVaccine = vc.getAvailableVaccine();
        //setVaccine();

    }

    private void loadData() throws IOException {
        recipients = new ArrayList<>();
        ArrayList<Recipient> unFilteredRecipients = new JsonHelper().readJsonFileToArrayList(JsonHelper.RECIPIENT_JSON_FILE, Recipient.class);

        for (Recipient r : unFilteredRecipients) {
            if (r.getVaccinationStatus() > 1 && r.getAppointments().get(0).getVaccinationCenter() != null && r.getAppointments().get(0).getVaccinationCenter().equalsIgnoreCase(name)) {
                this.recipients.add(r);
            }
        }

    }

    /* private void vaccineCounter() throws IOException {
        recipients = new ArrayList<>();
        ArrayList<Recipient> vaxBatch = new JsonHelper().readJsonFileToArrayList(JsonHelper.BATCH_JSON_FILE, Recipient.class);
        int count=0;

        for (Recipient r : vaxBatch) {
            count++;
        }

    } */

    /**
     * replace the old recipient object in the list with new recipient object
     *
     * @param recipient the latest recipient object
     */
    public void updateRecipientData(Recipient recipient) {
        for (int i = 0; i < recipients.size(); i++) {
            if (recipients.get(i).equals(recipient)) {
                recipients.set(i, recipient);
                break;
            }
        }
    }

    /**
     * get vaccination center's name
     *
     * @return vaccination center's name
     */
    public String getName() {
        return name;
    }

    /**
     * get capacity of the vaccination center per day
     *
     * @return capacity of the vaccination center per day
     */
    public int getCapacityPerDay() {
        return capacityPerDay;
    }

    /**
     * get the list of recipients
     *
     * @return the list of recipients who receive their vaccines in this vaccination center
     */
    public ArrayList<Recipient> getRecipients() {
        return recipients;
    }

    /**
     * add new doses received to the remaining doses
     *
     * @param number new doses received from Ministry of Health
     */
    public void increaseVaccine(int number) {
        this.availableVaccine += number;
    }

    /**
     * number of available vaccines from json
     *
     * 
     */
    public void setVaccine() throws IOException {
        this.availableVaccine = jsonHelper.vaxCounter(JsonHelper.BATCH_JSON_FILE);
        //this.availableVaccine = jsonHelper.vaxCounterLink(JsonHelper.BATCH_JSON_LINK);

    }

    

    /**
     * get the remaining vaccines of the vaccination center
     *
     * @return remaining vaccines of the vaccination center
     */
    public int getAvailableVaccine() {
        return availableVaccine;
    }


    private int checkCapacity(LocalDateTime selectedDate) {
        int capacity = capacityPerDay;
        for (Recipient recipient : recipients) {
            ArrayList<Appointment> appointments = recipient.getAppointments();
            Appointment lastAppointment = appointments.get(appointments.size() - 1);
            if (lastAppointment.getAppointmentDT() != null && lastAppointment.getAppointmentDT().truncatedTo(ChronoUnit.DAYS).isEqual(selectedDate))
                capacity--;
        }
        return capacity;
    }

    /**
     * set new appointment for the recipients based on their current status
     */
    public void setAppointmentDate() throws IOException {

        // set appointment date for 2nd dose, which is always 21 days after
        for (Recipient recipient : recipients) {
            if (recipient.getVaccinationStatus() == 3) {
                LocalDateTime firstDoseDate = recipient.getAppointments().get(0).getAppointmentDT().truncatedTo(ChronoUnit.DAYS);
                recipient.addNewAppointment(new Appointment(this.name, firstDoseDate.plusDays(NEXT_DOSE_DAYS).plusHours(9)));
            }
        }

        // set appointment date to recipients who are
        // 1. assigned to this vc
        // 2. reset date for those who miss their appointment
        LocalDateTime today = LocalDateTime.now().truncatedTo(ChronoUnit.DAYS);
        //LocalDateTime currentAppointmentDate = today.plusDays(1);
        LocalDateTime currentAppointmentDate = today;


        int remainingCapacity = checkCapacity(currentAppointmentDate);
        for (Recipient recipient : recipients) {
            while (remainingCapacity == 0) {
                currentAppointmentDate = currentAppointmentDate.plusDays(1);
                remainingCapacity = checkCapacity(currentAppointmentDate);
            }
            Appointment appointment = new Appointment(this.name, currentAppointmentDate.plusHours(9));
            if (recipient.getVaccinationStatus() == 2 && recipient.getAppointments().get(0).getAppointmentDT() == null)
                recipient.updateAppointment(0, appointment);
            else if (recipient.getVaccinationStatus() == 2 && recipient.getAppointments().get(0).getAppointmentDT().isBefore(today))
                recipient.updateAppointment(0, appointment);
            else if (recipient.getVaccinationStatus() == 4 && recipient.getAppointments().get(1).getAppointmentDT().isBefore(today))
                recipient.updateAppointment(1, appointment);
            else
                continue;
            remainingCapacity--;
            updateRecipientData(recipient);
        }
        saveData();
    }
    /**
     * increase recipient's vaccination status by 1
     */
    public void increaseVaccinationStatus(Recipient recipient) throws IOException{
            for (int i = 0; i < recipients.size(); i++) {
                if (recipients.get(i).equals(recipient)) {
                    if((recipients.get(i).getVaccinationStatus()== 2 && recipients.get(i).getAppointments().get(0).getAppointmentDT()!=null)
                    || (recipients.get(i).getVaccinationStatus()== 3 && recipients.get(i).getAppointments().get(1).getAppointmentDT()!=null)
                    || (recipients.get(i).getVaccinationStatus()== 4 && recipients.get(i).getAppointments().get(1).getAppointmentDT()!=null))
                    {
                    recipients.get(i).increaseVaccinationStatus();
                    break;
                    }
                }
            }
        saveData();
    }

    private void saveData() throws IOException {
        ArrayList<Recipient> originalRecipients = jsonHelper.readJsonFileToArrayList(JsonHelper.RECIPIENT_JSON_FILE, Recipient.class);
        for (Recipient recipient : recipients) {
            for (int i = 0; i < originalRecipients.size(); i++) {
                if (recipient.equals(originalRecipients.get(i))) {
                    originalRecipients.set(i, recipient);
                    break;
                }
            }
        }
        jsonHelper.writeJsonFile(originalRecipients, JsonHelper.RECIPIENT_JSON_FILE);
    }

    /**
     * every vaccination center has a unique name, if the names are same, the two objects are equal
     *
     * @param o different object
     * @return whether the object are same
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        VaccinationCenter that = (VaccinationCenter) o;
        return Objects.equals(name, that.name);
    }

}